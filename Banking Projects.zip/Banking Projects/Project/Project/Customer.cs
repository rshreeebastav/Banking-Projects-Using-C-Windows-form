﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
            bindgrid();
        }

        private void bindgrid()
        {
            banking_dbEntities2 bs = new banking_dbEntities2();
            var item = bs.userAccounts.ToList();
            dataGridView1.DataSource = item;
        }
    }
}
