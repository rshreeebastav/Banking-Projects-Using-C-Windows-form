﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void accountToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            newAccount newacc = new newAccount();
            newacc.MdiParent = this;
            newacc.Show();
        }

        private void updateSearchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Updation up = new Updation();
            up.MdiParent = this;
           up.Show();
        }

        private void allCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer ac = new Customer();
            ac.MdiParent = this;
            ac.Show();
        }

        private void depositToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Creditform dp = new Creditform();
            dp.MdiParent = this;
            dp.Show();
        }

        private void withdrawToolStripMenuItem_Click(object sender, EventArgs e)
        {
            withdraw wd = new withdraw();
            wd.MdiParent = this;
            wd.Show();
        }

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {

            transferamount tf = new transferamount();
            tf.MdiParent = this;
            tf.Show();
        }

        private void fDToolStripMenuItem_Click(object sender, EventArgs e)
        {

           fixeddeposit fd = new fixeddeposit();
            fd.MdiParent = this;
            fd.Show();
        }

        private void balanceSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            balancesheet bs = new balancesheet();
            bs.MdiParent = this;
            bs.Show();
        }

        private void viewFDToolStripMenuItem_Click(object sender, EventArgs e)
        {

            view vw = new view();
            vw.MdiParent = this;
            vw.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            changepassword cp = new changepassword();
            cp.MdiParent = this;
            cp.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }
    }
}
