﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class changepassword : Form
    {
        public changepassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            if (oldpasstxt.Text != string.Empty || newpasstxt.Text != string.Empty || repasstxt.Text != string.Empty)
            {
               Admin_Table user1 = dbe.Admin_Table.FirstOrDefault( a => a.Username.Equals(usrtxt.Text ) );
                if(user1 != null)
                {
                    if (user1.Password.Equals(oldpasstxt.Text))
                    {
                        user1.Password = newpasstxt.Text;
                        dbe.SaveChanges();
                        MessageBox.Show("Password Change successfully");
                    }
                    else
                    {
                        MessageBox.Show("Password incorrect");
                    }
                }

            }
        }
    }
}
