﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class transferamount : Form
    {
        public transferamount()
        {
            InitializeComponent();
            loaddate();

        }

        private void loaddate()
        {
           datelbl.Text = DateTime.UtcNow.ToString("MM/dd/yyyy");
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(formacctxt.Text);
            var item = (from u in dbe.userAccounts where u.Account_No==b select u).FirstOrDefault();
            nametxt.Text = item.Name;
            amounttxt.Text = Convert.ToString(item.Balance);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(formacctxt.Text);
            var item = (from u in dbe.userAccounts where u.Account_No == b select u).FirstOrDefault();
            decimal b1 = Convert.ToDecimal(item.Balance);
            decimal totalbal =  Convert.ToDecimal(transfertxt.Text);
            decimal transferacc = Convert.ToDecimal(desaccounttxt.Text);
            if (b1 > totalbal)
            {
                userAccount item2 = (from u in dbe.userAccounts where u.Account_No == transferacc select u).FirstOrDefault();
                item2.Balance = item2.Balance + totalbal;
                item.Balance = item.Balance - totalbal;
                Transfer transfer = new Transfer();
                transfer.Account_No = Convert.ToDecimal(formacctxt.Text);
                transfer.ToTransfer = Convert.ToDecimal(desaccounttxt.Text);
                transfer.Date = DateTime.UtcNow.ToString();
                transfer.Name = nametxt.Text;
                transfer.Balance = Convert.ToDecimal(transfertxt.Text);

                dbe.Transfers.Add(transfer);
                dbe.SaveChanges();
                MessageBox.Show("Transfer Successully");

            }
        }
    }
}
