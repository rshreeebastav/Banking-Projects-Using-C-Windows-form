﻿namespace Project
{
    partial class newAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.balancetxt = new System.Windows.Forms.TextBox();
            this.Fathetxt = new System.Windows.Forms.TextBox();
            this.mothertxt = new System.Windows.Forms.TextBox();
            this.disttxt = new System.Windows.Forms.TextBox();
            this.addtxt = new System.Windows.Forms.TextBox();
            this.phonetxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.accnotext = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.otherradio = new System.Windows.Forms.RadioButton();
            this.femaleradio = new System.Windows.Forms.RadioButton();
            this.maleradio = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.unmarriedradio = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.marriedradio = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.datelbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(148, 238);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(282, 20);
            this.dateTimePicker1.TabIndex = 55;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // balancetxt
            // 
            this.balancetxt.Location = new System.Drawing.Point(618, 443);
            this.balancetxt.Name = "balancetxt";
            this.balancetxt.Size = new System.Drawing.Size(282, 20);
            this.balancetxt.TabIndex = 53;
            this.balancetxt.TextChanged += new System.EventHandler(this.balancetxt_TextChanged);
            // 
            // Fathetxt
            // 
            this.Fathetxt.Location = new System.Drawing.Point(618, 402);
            this.Fathetxt.Name = "Fathetxt";
            this.Fathetxt.Size = new System.Drawing.Size(282, 20);
            this.Fathetxt.TabIndex = 52;
            this.Fathetxt.TextChanged += new System.EventHandler(this.Fathetxt_TextChanged);
            // 
            // mothertxt
            // 
            this.mothertxt.Location = new System.Drawing.Point(618, 364);
            this.mothertxt.Name = "mothertxt";
            this.mothertxt.Size = new System.Drawing.Size(282, 20);
            this.mothertxt.TabIndex = 51;
            this.mothertxt.TextChanged += new System.EventHandler(this.mothertxt_TextChanged);
            // 
            // disttxt
            // 
            this.disttxt.Location = new System.Drawing.Point(148, 364);
            this.disttxt.Name = "disttxt";
            this.disttxt.Size = new System.Drawing.Size(282, 20);
            this.disttxt.TabIndex = 50;
            this.disttxt.TextChanged += new System.EventHandler(this.disttxt_TextChanged);
            // 
            // addtxt
            // 
            this.addtxt.Location = new System.Drawing.Point(148, 321);
            this.addtxt.Name = "addtxt";
            this.addtxt.Size = new System.Drawing.Size(282, 20);
            this.addtxt.TabIndex = 49;
            this.addtxt.TextChanged += new System.EventHandler(this.addtxt_TextChanged);
            // 
            // phonetxt
            // 
            this.phonetxt.Location = new System.Drawing.Point(148, 280);
            this.phonetxt.Name = "phonetxt";
            this.phonetxt.Size = new System.Drawing.Size(282, 20);
            this.phonetxt.TabIndex = 48;
            this.phonetxt.TextChanged += new System.EventHandler(this.phonetxt_TextChanged);
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(148, 201);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(282, 20);
            this.nametxt.TabIndex = 47;
            this.nametxt.TextChanged += new System.EventHandler(this.nametxt_TextChanged);
            // 
            // accnotext
            // 
            this.accnotext.Location = new System.Drawing.Point(148, 157);
            this.accnotext.Name = "accnotext";
            this.accnotext.Size = new System.Drawing.Size(282, 20);
            this.accnotext.TabIndex = 46;
            this.accnotext.TextChanged += new System.EventHandler(this.accnotext_TextChanged);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(195, 473);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 28);
            this.button2.TabIndex = 45;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(668, 189);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(194, 28);
            this.button1.TabIndex = 44;
            this.button1.Text = "Upload Photo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(668, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(194, 137);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // otherradio
            // 
            this.otherradio.AutoSize = true;
            this.otherradio.Location = new System.Drawing.Point(240, 38);
            this.otherradio.Name = "otherradio";
            this.otherradio.Size = new System.Drawing.Size(56, 17);
            this.otherradio.TabIndex = 2;
            this.otherradio.TabStop = true;
            this.otherradio.Text = "Others";
            this.otherradio.UseVisualStyleBackColor = true;
            this.otherradio.CheckedChanged += new System.EventHandler(this.otherradio_CheckedChanged);
            // 
            // femaleradio
            // 
            this.femaleradio.AutoSize = true;
            this.femaleradio.Location = new System.Drawing.Point(149, 38);
            this.femaleradio.Name = "femaleradio";
            this.femaleradio.Size = new System.Drawing.Size(59, 17);
            this.femaleradio.TabIndex = 1;
            this.femaleradio.TabStop = true;
            this.femaleradio.Text = "Female";
            this.femaleradio.UseVisualStyleBackColor = true;
            this.femaleradio.CheckedChanged += new System.EventHandler(this.femaleradio_CheckedChanged);
            // 
            // maleradio
            // 
            this.maleradio.AutoSize = true;
            this.maleradio.Location = new System.Drawing.Point(46, 34);
            this.maleradio.Name = "maleradio";
            this.maleradio.Size = new System.Drawing.Size(48, 17);
            this.maleradio.TabIndex = 0;
            this.maleradio.TabStop = true;
            this.maleradio.Text = "Male";
            this.maleradio.UseVisualStyleBackColor = true;
            this.maleradio.CheckedChanged += new System.EventHandler(this.maleradio_CheckedChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(148, 405);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(282, 21);
            this.comboBox1.TabIndex = 54;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.otherradio);
            this.groupBox2.Controls.Add(this.femaleradio);
            this.groupBox2.Controls.Add(this.maleradio);
            this.groupBox2.Location = new System.Drawing.Point(580, 219);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 58);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Gender";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // unmarriedradio
            // 
            this.unmarriedradio.AutoSize = true;
            this.unmarriedradio.Location = new System.Drawing.Point(149, 38);
            this.unmarriedradio.Name = "unmarriedradio";
            this.unmarriedradio.Size = new System.Drawing.Size(73, 17);
            this.unmarriedradio.TabIndex = 1;
            this.unmarriedradio.TabStop = true;
            this.unmarriedradio.Text = "Unmarried";
            this.unmarriedradio.UseVisualStyleBackColor = true;
            this.unmarriedradio.CheckedChanged += new System.EventHandler(this.unmarriedradio_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.unmarriedradio);
            this.groupBox1.Controls.Add(this.marriedradio);
            this.groupBox1.Location = new System.Drawing.Point(580, 283);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 58);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Maritial Status";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // marriedradio
            // 
            this.marriedradio.AutoSize = true;
            this.marriedradio.Location = new System.Drawing.Point(46, 34);
            this.marriedradio.Name = "marriedradio";
            this.marriedradio.Size = new System.Drawing.Size(60, 17);
            this.marriedradio.TabIndex = 0;
            this.marriedradio.TabStop = true;
            this.marriedradio.Text = "Married";
            this.marriedradio.UseVisualStyleBackColor = true;
            this.marriedradio.CheckedChanged += new System.EventHandler(this.marriedradio_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(528, 446);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(46, 13);
            this.label13.TabIndex = 40;
            this.label13.Text = "Balance";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(528, 402);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 13);
            this.label12.TabIndex = 39;
            this.label12.Text = "Father\'s Name";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(528, 367);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = "Mother\'s Name";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(44, 405);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 37;
            this.label10.Text = "State";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(44, 364);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 36;
            this.label9.Text = "District";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(44, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Address";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 283);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 13);
            this.label7.TabIndex = 34;
            this.label7.Text = "Phone Number";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "DOB";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 201);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 32;
            this.label5.Text = "Name";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 31;
            this.label4.Text = "Account No.";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Location = new System.Drawing.Point(499, 89);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(52, 13);
            this.datelbl.TabIndex = 30;
            this.datelbl.Text = "Datelabel";
            this.datelbl.Click += new System.EventHandler(this.datelbl_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(363, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "Current Date";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(330, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "Customer Information Form";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // newAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(945, 546);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.balancetxt);
            this.Controls.Add(this.Fathetxt);
            this.Controls.Add(this.mothertxt);
            this.Controls.Add(this.disttxt);
            this.Controls.Add(this.addtxt);
            this.Controls.Add(this.phonetxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.accnotext);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "newAccount";
            this.Text = "newAccount";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox balancetxt;
        private System.Windows.Forms.TextBox Fathetxt;
        private System.Windows.Forms.TextBox mothertxt;
        private System.Windows.Forms.TextBox disttxt;
        private System.Windows.Forms.TextBox addtxt;
        private System.Windows.Forms.TextBox phonetxt;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox accnotext;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton otherradio;
        private System.Windows.Forms.RadioButton femaleradio;
        private System.Windows.Forms.RadioButton maleradio;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton unmarriedradio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton marriedradio;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}