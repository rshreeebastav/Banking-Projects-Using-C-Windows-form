﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class newAccount : Form
    {
        string gender = string.Empty;
        string m_status = string.Empty;
        decimal no;
        banking_dbEntities2 BSE;
        MemoryStream ms;
        public newAccount()
        {
            InitializeComponent();
            loaddate();
            loadaccount();
            loadstate();


        }

        private void loadstate()
        {
            comboBox1.Items.Add("AP | Andhra Pradesh");
            comboBox1.Items.Add("AR | Arunachal Pradesh");
            comboBox1.Items.Add("AS | Assam");
            comboBox1.Items.Add("BR | Bihar");
            comboBox1.Items.Add("CT | Chhattisgarh");
            comboBox1.Items.Add("GA | Goa");
            comboBox1.Items.Add("GJ | Gujarat");
            comboBox1.Items.Add("HR | Haryana");
            comboBox1.Items.Add("JK | Jammu and Kashmir");
            comboBox1.Items.Add("JH | Jharkhand");
            comboBox1.Items.Add("KA | Karnataka");
            comboBox1.Items.Add("KL | Kerala");
            comboBox1.Items.Add("MP | Madhya Pradesh");
            comboBox1.Items.Add("MH | Maharashtra");





            comboBox1.Items.Add("MN | Manipur");
            comboBox1.Items.Add("ML | Meghalaya");
            comboBox1.Items.Add("(MZ | Mizoram");
            comboBox1.Items.Add("NL | Nagaland");
            comboBox1.Items.Add("OR | Odisha");
            comboBox1.Items.Add("PB | Punjab");
            comboBox1.Items.Add("RJ | Rajasthan");
            comboBox1.Items.Add("SK | Sikkim");
            comboBox1.Items.Add("TN | Tamil Nadu");
            comboBox1.Items.Add("TG | Telangana");
            comboBox1.Items.Add("TR | Tripura");
            comboBox1.Items.Add("UT | Uttarakhand");
            comboBox1.Items.Add("UP | Uttar Pradesh");
            comboBox1.Items.Add("WB | West Bengal");
            comboBox1.Items.Add("AN | Andaman and Nicobar Islands");
            comboBox1.Items.Add("CH | Chandigarh");
            comboBox1.Items.Add("DN | Dadra and Nagar Haveli");
            comboBox1.Items.Add("DD | Daman and Diu");
            comboBox1.Items.Add("DL | Delhi");
            comboBox1.Items.Add("LD | Lakshadweep");
            comboBox1.Items.Add("PY | Puducherry");
        }

        private void loadaccount()
        {
            BSE = new banking_dbEntities2();
            var item = BSE.userAccounts.ToArray();
            no = item.LastOrDefault().Account_No + 1;
            accnotext.Text = Convert.ToString(no);
        }

        private void loaddate()
        {
            datelbl.Text = DateTime.Now.ToString("MM/dd/yyyy");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog opebdlg = new OpenFileDialog();
            if (opebdlg.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(opebdlg.FileName);
                pictureBox1.Image = img;
                ms = new MemoryStream();
                img.Save(ms, img.RawFormat);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (maleradio.Checked)
            {
                gender = "male";

            }
            else if (femaleradio.Checked)
            {
                gender = "female";
            }
            else if (otherradio.Checked)
            {
                gender = "other";
            }

            if (marriedradio.Checked)
            {
                m_status = "married";

            }
            else if (unmarriedradio.Checked)
            {
                m_status = "Un-Married";
            }
            BSE = new banking_dbEntities2();
            userAccount acc = new userAccount();
            acc.Account_No = Convert.ToDecimal(accnotext.Text);
            acc.Name = nametxt.Text;
            acc.DOB = dateTimePicker1.Value.ToString();
            acc.PhoneNo = phonetxt.Text;
            acc.Address = addtxt.Text;
            acc.District = disttxt.Text;
            acc.State = comboBox1.SelectedItem.ToString();
            acc.Gender = gender;
            acc.Maritial_status = m_status;
            acc.Mother_Name = mothertxt.Text;
            acc.Father_Name = Fathetxt.Text;

            acc.Balance = Convert.ToDecimal(balancetxt.Text);
            acc.Date = datelbl.Text;
            acc.Picture = ms.ToArray();
            BSE.userAccounts.Add(acc);

            BSE.SaveChanges();
            MessageBox.Show("File saved");
        }

        private void balancetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fathetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void mothertxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void disttxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void addtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void phonetxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void nametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void accnotext_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void otherradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void femaleradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void maleradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void unmarriedradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void marriedradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void datelbl_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
    

