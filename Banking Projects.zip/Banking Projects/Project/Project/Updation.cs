﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Updation : Form

    {

        banking_dbEntities2 dbe;
        MemoryStream ms;
        BindingList<userAccount> bi;
        public Updation()
        {
            InitializeComponent();
            loaddate();
        }

        private void loaddate()
        {
              datelbl.Text = DateTime.UtcNow.ToString("MM/dd/yyyy");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            bi = new BindingList<userAccount>();
            dbe = new banking_dbEntities2();
            decimal accno = Convert.ToDecimal(accnotext.Text);
            var item = dbe.userAccounts.Where(a => a.Account_No == accno);
            foreach (var item1 in item)
            {
                bi.Add(item1);
            }
            dataGridView1.DataSource = bi;

        }

        private void button4_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\rahul\\OneDrive\\Documents\\banking_db.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from userAccount", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dbe = new banking_dbEntities2();
            decimal accno = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
            var item = dbe.userAccounts.Where(a => a.Account_No == accno).FirstOrDefault();
            accnotext.Text = item.Account_No.ToString();
            nametxt.Text = item.Name;
            mothertxt.Text = item.Mother_Name;
            Fathetxt.Text = item.Father_Name;
            phonetxt.Text = item.PhoneNo;
            addtxt.Text = item.Address;
            byte[] img = item.Picture;
            MemoryStream ms = new MemoryStream(img);
            pictureBox1.Image = Image.FromStream(ms);
            disttxt.Text = item.District;
            statetxt.Text = item.State;
            if (item.Gender == "male")
            {
                maleradio.Checked = true;
            }
            else if(item.Gender == "female")
            {
                femaleradio.Checked = true;
            }
            else if (item.Gender == "female")
            {
                otherradio.Checked = true;
            }
            if(item.Maritial_status == "married")
            {
                marriedradio.Checked = true;
            }
            else if (item.Maritial_status == "Unmarried")
            {
                unmarriedradio.Checked = true;

            }


        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\rahul\\OneDrive\\Documents\\banking_db.mdf;Integrated Security=True;Connect Timeout=30");
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete userAccount  where Account_No=@Account_No", con);
            cmd.Parameters.AddWithValue("@Account_No", double.Parse(accnotext.Text));
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Successfully Deleted");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog opebdlg = new OpenFileDialog();
            if (opebdlg.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(opebdlg.FileName);
                pictureBox1.Image = img;
                ms = new MemoryStream();
                img.Save(ms, img.RawFormat);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dbe = new banking_dbEntities2();
            decimal accountno = Convert.ToDecimal(accnotext.Text);
            userAccount useraccount = dbe.userAccounts.First(s => s.Account_No.Equals(accountno));
            useraccount.Account_No = Convert.ToDecimal(accnotext.Text);
            useraccount.Name = nametxt.Text;
            useraccount.Date = dateTimePicker1.Value.ToString();
            useraccount.Mother_Name = mothertxt.Text;
            useraccount.Father_Name = Fathetxt.Text;
            useraccount.PhoneNo = phonetxt.Text;
            if (maleradio.Checked == true)
            {
                useraccount.Gender = "male";
            }
            else
            {
                if (femaleradio.Checked == true)
                    useraccount.Gender = "female";
            }
            if (marriedradio.Checked == true)
            {
                useraccount.Maritial_status = "married";
            }
            else
            {
                if (unmarriedradio.Checked == true)
                    useraccount.Maritial_status = "Un-Married";
            }
            Image img = pictureBox1.Image;
                    if (img.RawFormat != null)
                    {
                        if (ms != null)
                        {
                            img.Save(ms, img.RawFormat);
                            useraccount.Picture = ms.ToArray();
                        }
                    }
                    useraccount.Address = addtxt.Text;
                    useraccount.District = disttxt.Text;
                    useraccount.State = statetxt.Text;
                    dbe.SaveChanges();
                    MessageBox.Show("Updated Successfully");
                }
            }

        }
