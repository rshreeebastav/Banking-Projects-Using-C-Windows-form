﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Creditform : Form
    {
        public Creditform()
        {
            InitializeComponent();
            loaddate();
            loadmode();
        }

        private void loadmode()
        {
            comboBox1.Items.Add("Cash");
            comboBox1.Items.Add("Cheque");

        }

        private void loaddate()
        {
            datetbl.Text = DateTime.UtcNow.ToString("MM/dd/yyyy");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 context = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(acctxt.Text);
            var item = (from u in context.userAccounts where u.Account_No == b select u).FirstOrDefault();  
            nametxt.Text = item.Name;
            oldbaltxt.Text = Convert.ToString(item.Balance);
        }

        private void update(object sender, EventArgs e)
        {
            banking_dbEntities2 context = new banking_dbEntities2();
            newAccount acc = new newAccount();
            Deposit dp = new Deposit();
            dp.Date = datetbl.Text;
            dp.Name = nametxt.Text;
            dp.OldBalance = Convert.ToDecimal(oldbaltxt.Text);
            dp.Mode = comboBox1.SelectedItem.ToString();
            dp.DipAmount = Convert.ToDecimal(amounttxt.Text);
            context.Deposits.Add(dp);
            context.SaveChanges();
            decimal b = Convert.ToDecimal(acctxt.Text);
            var item = (from u in context.userAccounts where u.Account_No == b select u).FirstOrDefault();
            item.Balance = item.Balance + Convert.ToDecimal(amounttxt.Text);
            context.SaveChanges();
            MessageBox.Show("Deposit successfully");

        }

        private void Creditform_Load(object sender, EventArgs e)
        {

        }
    }
}
